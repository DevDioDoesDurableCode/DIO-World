events = {}

def addEvents(content,year):
  events[len(events)] = content+" | Year: "+str(year)